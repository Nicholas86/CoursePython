Subjects
========

All of behave exactly the same like described [here](http://reactivex.io/documentation/subject.html)
