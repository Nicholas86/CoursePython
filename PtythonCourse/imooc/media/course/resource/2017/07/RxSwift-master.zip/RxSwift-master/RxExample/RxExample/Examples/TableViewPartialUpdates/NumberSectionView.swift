//
//  NumberSectionView.swift
//  RxExample
//
//  Created by Krunoslav Zaher on 7/2/15.
//  Copyright © 2015 Krunoslav Zaher. All rights reserved.
//

import UIKit

class NumberSectionView : UICollectionReusableView {
   @IBOutlet weak var value: UILabel?
}
