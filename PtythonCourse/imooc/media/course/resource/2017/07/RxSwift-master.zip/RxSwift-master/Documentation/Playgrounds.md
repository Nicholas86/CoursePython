## Playgrounds

To use playgrounds:

* Open `Rx.xcworkspace`
* Build the `RxSwift-macOS` scheme
* Open `Rx` playground in the `Rx.xcworkspace` tree view.
* Choose `View > Debug Area > Show Debug Area`
