//
//  NumberCell.swift
//  RxExample
//
//  Created by Krunoslav Zaher on 7/2/15.
//  Copyright © 2015 Krunoslav Zaher. All rights reserved.
//

import UIKit

class NumberCell : UICollectionViewCell {
    @IBOutlet var value: UILabel?
}
